__tags__ = []

import sys
if sys.version_info >= (3, 0, 0):
    __tags__.extend(('ignore', 'subprocess_ignore'))

